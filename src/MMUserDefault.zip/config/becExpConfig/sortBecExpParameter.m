function parameterListSorted = sortBecExpParameter(parameterList)
%SORTBECEXPTRIALNAME Summary of this function goes here
%   Detailed explanation goes here

parameterList(parameterList == "RunIndex" | parameterList == "CiceroLogTime") = [];
parameterList = sort(parameterList);
if ~isempty(parameterList)
    parameterListSorted = ["RunIndex";"CiceroLogTime";parameterList];
else
    parameterListSorted = ["RunIndex";"CiceroLogTime"];
end

end


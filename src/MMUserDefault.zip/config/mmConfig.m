% This is a script to set the user-defined configurations

%% Path
HardwareLogOrigin = "YourHardwareLogOrigin"; %The path where all Hardware logs are temporarily saved

%% Database
BecExpDatabaseName = "alkali_experiment"; %The postgresql database name for saving the experimental metadata. Just give it a name.
BecExpDatabaseTableName = "main"; %The table. Usually I use 'main'.
ServerName = ["localhost";"localhost"]; %The first server has to be localhost. The second is assumed to be remote.
Port = [5432;5432];
Username = ["postgres";"postgres";]; %The master username/password you use when you install PostgreSQL
Password = ["SupermassiveBlackHole";"SupermassiveBlackHole"];

%% Acquisition
% Define your acquisition here as a table with columns:
% Name: name of your AWG
% DeviceModel: Manufacture + model. It has to be a supported class
% DeviceID: ID of the devicce if multiple devices share the same adaptor
% SerialNumber: Camera serial number
% ExposureTime: Exposure time in [us]
% Magnification: Your optical system's magnification
% Transmission: Your optical system's transmission
% BadRow: Rows that have bad pixels
AcquisitionConfig = cell2table( ...
    { ...
    "YourCameraName", "AndorIXon888", 0,14277 , 30e-6 ,3.337676782237963, 1,[] ;...
    },...
    "VariableNames",["Name","DeviceModel","DeviceID",...
    "SerialNumber","ExposureTime","Magnification","Transmission","BadRow"]);

%% Waveform generator
% Define your waveform generator here as a table with columns:
% Name: name of your AWG
% DeviceModel: Manufacture + model. It has to be a supported class
% ResourceName: The VISA address or the TCP address
WaveformGeneratorConfig = cell2table( ...
    { ...
    "YourAWGName","Keysight33600A","TCPIP0::172.16.0.3::inst0::INSTR"; ...
    },...
    "VariableNames",["Name","DeviceModel","ResourceName"]);

%% Scope
% Define your scope here as a table with columns:
% Name: name of your scope
% DeviceModel: Manufacture + model. It has to be a supported class
% ResourceName: The VISA address or the TCP address
ScopeConfig = cell2table( ...
    { ...
    "YourScopeName","SiglentSDS2104XPlus","TCPIP0::172.16.0.6::inst0::INSTR"; ...
    },...
    "VariableNames",["Name","DeviceModel","ResourceName"]);

%% Phase lock
% Define your phase lock here as a table with columns:
% Name: name of your scope
% DeviceModel: Manufacture + model. It has to be a supported class
% ResourceName: The VISA address or the TCP address
PhaseLockConfig = cell2table( ...
    { ...
    "YourPhaseLockName","VescentSlice","COM6"; ...
    },...
    "VariableNames",["Name","DeviceModel","ResourceName"]);

%% BecExp
CiceroComputerName = "YourCeciroComputurName"; %The name of the computer running Cicero
CiceroLogOrigin = "YourCiceroLogOriginPath"; %The path where Cicero logs are temporarily saved
BecExpControlComputerName = "YourMMComputerName"; %The name of the computer running BecExp analysis
BecExpParentPath = "YourBecExpDataPath"; %The path where BecExp analysis data are saved
BecExpDataPrefix = "run";
BecExpDataFormat = ".tif"; 
BecExpIsAutoDelete = false; %If you want to auto delete empty BecExp data folders
BecExpDataGroupSize = 3;
BecExpIsAutoAcquire = true;
BecExpOdColormap = {jet}; %Change to your favorite colormap
BecExpAtomName = "Lithium7";
BecExpImagingStageList = ["LF","HF","NI"]; %List your possible imaging stages here. For example, if you do imaging at low/high magnetic fields, type ["LF","HF"].
BecExpVariableMapping = [ ...
    "ImagingTime","t_image";...
    "TofTime","TOF";...
    "KdPulseTime","KdPulseTime";...
    ]; % Modify the right column as per your Cicero variable names.

%% Simulation
SimParentPath = "YourSimulationDataPath";
SimDatabaseName = "simulation";
SimDataPrefix = "run";
SimDataFormat = ".mat"; 
SimIsAutoDelete = false;

LatticeSeSim1D_DatabaseTableName = "lattice_schrodinger_equation_simulation_1d";
LatticeSeSim1D_OutputVariableName = "WaveFunction";

LatticeFourierSeSim1D_DatabaseTableName = "lattice_fourier_simulation_1d";
LatticeFourierSeSim1D_OutputVariableName = "WaveFunction";


